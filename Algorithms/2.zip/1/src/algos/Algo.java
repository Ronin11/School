package algos;

public abstract class Algo {
	public abstract boolean win(int a, int b, int c);
}
