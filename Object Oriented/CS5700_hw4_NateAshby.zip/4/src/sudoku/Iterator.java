package sudoku;

public interface Iterator {
	public boolean hasNext();
	public Cell next();

}
