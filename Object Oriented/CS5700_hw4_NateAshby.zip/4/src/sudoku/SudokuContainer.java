package sudoku;

public interface SudokuContainer {
	public Iterator getIterator();
}
