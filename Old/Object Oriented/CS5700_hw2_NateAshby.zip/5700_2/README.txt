To run this program successfully, you must allow your Gmail to have access from less secure apps. Give it a quick google and it pops right up.
You must also open the Email.java file and replace the following code:
	String gmailUserName = "";
	String gmailPassword = "";
Put your gmail address and gmail password in these fields and then it will run like a champ.

There are 3 elements in the GUI toolbar that displays the requirements. One does the cheaters, one allows you to create a support team. The main display is initially populated with the 1st 30 racers. If you want to select different ones, theres a menu item for that as well.